<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

use App\Models\User;
use App\Models\Department;
use App\Models\Job;

class DeleteLdapDataSeeder extends Seeder
{
    public function run(): void
    {
        Schema::disableForeignKeyConstraints(); // FK = 0

        DB::transaction(function () {

            /*
            |--------------------------------------------------------------------------
            | 1. Get LDAP users
            |--------------------------------------------------------------------------
            */
            $ldapUsers = User::where('type', 'ldap')->get();

            if ($ldapUsers->isEmpty()) {
                return;
            }

            /*
            |--------------------------------------------------------------------------
            | 2. Collect related IDs
            |--------------------------------------------------------------------------
            */
            $departmentIds = $ldapUsers
                ->pluck('department_id')
                ->filter()
                ->unique()
                ->values();

            $jobIds = $ldapUsers
                ->pluck('job_id')
                ->filter()
                ->unique()
                ->values();

            /*
            |--------------------------------------------------------------------------
            | 3. Delete LDAP users
            |--------------------------------------------------------------------------
            */
            User::where('type', 'ldap')->delete();

            /*
            |--------------------------------------------------------------------------
            | 4. Recursively delete departments + parents
            |--------------------------------------------------------------------------
            */
            foreach ($departmentIds as $departmentId) {
                $this->deleteDepartmentWithParents($departmentId);
            }

            /*
            |--------------------------------------------------------------------------
            | 5. Delete jobs (only if unused)
            |--------------------------------------------------------------------------
            */
            foreach ($jobIds as $jobId) {
                if (!User::where('job_id', $jobId)->exists()) {
                    Job::where('id', $jobId)->delete();
                }
            }
        });

        Schema::enableForeignKeyConstraints(); // FK = 1

        $this->command->info('LDAP users, departments, and parent hierarchy deleted.');
    }

    /**
     * Recursively delete department and its parents if unused
     */
    private function deleteDepartmentWithParents(?int $departmentId): void
    {
        if (!$departmentId) {
            return;
        }

        $department = Department::find($departmentId);

        if (!$department) {
            return;
        }

        // If still used by any user → STOP
        if (User::where('department_id', $department->id)->exists()) {
            return;
        }

        $parentId = $department->parent_id;

        // Delete current department
        $department->delete();

        // Recursively delete parent
        if ($parentId) {
            $this->deleteDepartmentWithParents($parentId);
        }
    }
}
