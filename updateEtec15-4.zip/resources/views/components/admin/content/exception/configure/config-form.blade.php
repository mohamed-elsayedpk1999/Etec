<link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
<style>
    .select2-container--default .select2-selection--single {
        background-color: #fff;
        border: 1px solid #dee2e6;
        border-radius: 0.375rem;
        height: auto;
        padding: 0.375rem 0.75rem;
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: #495057;
        padding: 0;
        line-height: 1.5;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 100%;
        right: 0.75rem;
    }

    .select2-container--default .select2-selection--single:focus {
        border-color: #86b7fe;
        outline: 0;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }

    .select2-container--default.select2-container--focus .select2-selection--single {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }

    .select2-dropdown {
        border: 1px solid #dee2e6;
        border-radius: 0.375rem;
    }

    .select2-results__option {
        padding: 0.5rem 0.75rem;
    }

    .select2-results__option--highlighted {
        background-color: #0d6efd;
        color: white;
    }

    .select2-search__field {
        padding: 0.375rem 0.75rem;
        border-bottom: 1px solid #dee2e6;
    }

    .select2-container--default .select2-search--dropdown .select2-search__field {
        border: 1px solid #dee2e6;
        border-radius: 0.375rem 0.375rem 0 0;
    }
</style>

<div class="modal fade" id="{{ $id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body dark-modal">
                <div class="text-center mb-4">
                    <h2 class="modal-title" id="myExtraLargeModal">{{ $title }}</h2>
                </div>
                <form action="{{ route('admin.governance.exception.config.store') }}" method="POST"
                    class="modal-content pt-4 p-3" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id">

                    <div class="row">

                        {{-- Policy Approver --}}
                        <div class="col-12 mb-3" id="policy_approver">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.PolicyApprover') }} <span
                                        class="text-danger">*</span></label>
                                <select name="policy_approver" class="form-control dt-post"
                                    aria-label="{{ __('locale.PolicyApprover') }}">
                                    <option value="0"
                                        {{ $exceptionSettings[0]['policy_approver'] == 0 ? 'selected' : '' }}>
                                        {{ __('locale.PolicyOwner') }}
                                    </option>
                                    <option value="1"
                                        {{ $exceptionSettings[0]['policy_approver'] == 1 ? 'selected' : '' }}>
                                        {{ __('locale.AnyPerson') }}
                                    </option>

                                </select>
                                <span class="error error-policy text-danger my-2"></span>
                            </div>
                        </div>

                        {{-- policy approver user --}}
                        <div class="col-12 mb-3" id="policy_approver_user" style="display: none;">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.PleaseSelectThePolicyApprover') }} <span
                                        class="text-danger">*</span></label>
                                <select name="policy_approver_id" class="form-control dt-post"
                                    aria-label="{{ __('locale.PleaseSelectThePolicyApprover') }}">
                                    <option value="" selected> -- </option>
                                    @foreach ($departmentsManagers as $user)
                                        <option value="{{ $user->id }}"
                                            {{ $user->id == $exceptionSettings[0]['policy_approver_id'] ? 'selected' : '' }}>
                                            {{ $user->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="error error-owner text-danger my-2"></span>
                            </div>
                        </div>

                        {{-- Control approver --}}
                        <div class="col-12 mb-3" id="control_approver">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.ControlApprover') }} <span
                                        class="text-danger">*</span></label>
                                <select name="control_approver" class="form-control dt-post"
                                    aria-label="{{ __('locale.ControlApprover') }}">
                                    <option value="0"
                                        {{ $exceptionSettings[0]['control_approver'] == 0 ? 'selected' : '' }}>
                                        {{ __('locale.ControlOwner') }}
                                    </option>
                                    <option value="1"
                                        {{ $exceptionSettings[0]['control_approver'] == 1 ? 'selected' : '' }}>
                                        {{ __('locale.AnyPerson') }}
                                    </option>
                                </select>
                                <span class="error error-policy text-danger my-2"></span>
                            </div>
                        </div>

                        {{-- control approver user --}}
                        <div class="col-12 mb-3" id="control_approver_user" style="display: none;">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.PleaseSelectTheControlApprover') }} <span
                                        class="text-danger">*</span></label>
                                <select name="control_approver_id" class="form-control dt-post"
                                    aria-label="{{ __('locale.PleaseSelectThePolicyApprover') }}">
                                    <option value="" selected> -- </option>
                                    @foreach ($departmentsManagers as $user)
                                        <option value="{{ $user->id }}"
                                            {{ $user->id == $exceptionSettings[0]['control_approver_id'] ? 'selected' : '' }}>
                                            {{ $user->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="error error-owner text-danger my-2"></span>
                            </div>
                        </div>

                        {{-- Risk approver --}}
                        <div class="col-12 mb-3" id="risk_approver">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.RiskApprover') }} <span
                                        class="text-danger">*</span></label>
                                <select name="risk_approver" class="form-control dt-post"
                                    aria-label="{{ __('locale.RiskApprover') }}">
                                    <option value="0"
                                        {{ $exceptionSettings[0]['risk_approver'] == 0 ? 'selected' : '' }}>
                                        {{ __('locale.RiskOwner') }}
                                    </option>
                                    <option value="1"
                                        {{ $exceptionSettings[0]['risk_approver'] == 1 ? 'selected' : '' }}>
                                        {{ __('locale.AnyPerson') }}
                                    </option>
                                </select>
                                <span class="error error-risk text-danger my-2"></span>
                            </div>
                        </div>

                        {{-- Risk approver user --}}
                        <div class="col-12 mb-3" id="risk_approver_user" style="display: none;">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.PleaseSelectTheRiskApprover') }} <span
                                        class="text-danger">*</span></label>
                                <select name="risk_approver_id" class="form-control dt-post"
                                    aria-label="{{ __('locale.PleaseSelectTheRiskApprover') }}">
                                    <option value="" selected> -- </option>
                                    @foreach ($departmentsManagers as $user)
                                        <option value="{{ $user->id }}"
                                            {{ $user->id == $exceptionSettings[0]['risk_approver_id'] ? 'selected' : '' }}>
                                            {{ $user->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="error error-owner text-danger my-2"></span>
                            </div>
                        </div>
                    </div>
                    <button type="Submit" class="btn btn-primary data-submit me-1">
                        {{ __('locale.Submit') }}</button>
            </div>
            </form>
        </div>
    </div>
</div>
</div>


<script>
    document.querySelector('#policy_approver select[name="policy_approver"]').addEventListener('change', function() {
        var approverSelectDiv = document.getElementById('policy_approver_user');
        if (this.value == "1") {
            approverSelectDiv.style.display = 'block';
        } else {
            approverSelectDiv.style.display = 'none';
        }
    });

    document.querySelector('#policy_approver select[name="policy_approver"]').dispatchEvent(new Event('change'));
</script>

<script>
    document.querySelector('#control_approver select[name="control_approver"]').addEventListener('change', function() {
        var approverSelectDiv = document.getElementById('control_approver_user');
        if (this.value == "1") {
            approverSelectDiv.style.display = 'block';
        } else {
            approverSelectDiv.style.display = 'none';
        }
    });

    document.querySelector('#control_approver select[name="control_approver"]').dispatchEvent(new Event('change'));
</script>

<script>
    document.querySelector('#risk_approver select[name="risk_approver"]').addEventListener('change', function() {
        var approverSelectDiv = document.getElementById('risk_approver_user');
        if (this.value == "1") {
            approverSelectDiv.style.display = 'block';
        } else {
            approverSelectDiv.style.display = 'none';
        }
    });

    document.querySelector('#risk_approver select[name="risk_approver"]').dispatchEvent(new Event('change'));
</script>

<script src="{{ asset('cdn/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>

<script>
    $(document).ready(function() {
        var modalElement = document.getElementById('{{ $id }}');

        if (modalElement) {
            $(modalElement).on('shown.bs.modal', function() {
                try {
                    $('select[name="policy_approver_id"]').select2('destroy');
                    $('select[name="control_approver_id"]').select2('destroy');
                    $('select[name="risk_approver_id"]').select2('destroy');
                } catch (e) {}

                setTimeout(function() {
                    initializeSelect2();
                }, 100);
            });
        }
    });

    function initializeSelect2() {
        var modalElement = document.getElementById('{{ $id }}');
        var modalJQuery = $(modalElement);

        $('select[name="policy_approver_id"]').select2({
            placeholder: "{{ __('locale.PleaseSelectThePolicyApprover') }}",
            allowClear: true,
            width: '100%',
            dropdownParent: modalJQuery,
            matcher: function(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.toUpperCase().indexOf(params.term.toUpperCase()) > -1) {
                    return data;
                }
                return null;
            }
        });

        $('select[name="control_approver_id"]').select2({
            placeholder: "{{ __('locale.PleaseSelectTheControlApprover') }}",
            allowClear: true,
            width: '100%',
            dropdownParent: modalJQuery,
            matcher: function(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.toUpperCase().indexOf(params.term.toUpperCase()) > -1) {
                    return data;
                }
                return null;
            }
        });

        $('select[name="risk_approver_id"]').select2({
            placeholder: "{{ __('locale.PleaseSelectTheRiskApprover') }}",
            allowClear: true,
            width: '100%',
            dropdownParent: modalJQuery,
            matcher: function(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.toUpperCase().indexOf(params.term.toUpperCase()) > -1) {
                    return data;
                }
                return null;
            }
        });
    }
</script>
