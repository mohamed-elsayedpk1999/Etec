<?php

namespace App\Jobs;

use App\Models\Vulnerability;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ImportQualysVulnJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $vulns;

    /**
     * Create a new job instance.
     *
     * @param array $vulns
     */
    public function __construct(array $vulns)
    {
        $this->vulns = $vulns;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        foreach ($this->vulns as $vuln) {
            Vulnerability::create([
                'name' => $vuln['title'] ?? 'Qualys Vuln',
                'description' => $vuln['impact'] ?? '',
                'severity' => $vuln['severity'] ?? 'Low',
                'recommendation' => $vuln['solution'] ?? '',
                'status' => 'Open',
                'plugin_id' => $vuln['qid'],
                'created_by' => 1,
            ]);
        }
    }
}
