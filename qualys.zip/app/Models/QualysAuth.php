<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QualysAuth extends Model
{
    use HasFactory;
    protected $guarded = [];
}
